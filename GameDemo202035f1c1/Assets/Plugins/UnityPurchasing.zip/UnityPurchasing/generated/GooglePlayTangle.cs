#if UNITY_ANDROID || UNITY_IPHONE || UNITY_STANDALONE_OSX || UNITY_TVOS
// WARNING: Do not modify! Generated file.

namespace UnityEngine.Purchasing.Security {
    public class GooglePlayTangle
    {
        private static byte[] data = System.Convert.FromBase64String("9MAQ4XqhnqMWF8rLB2l7eKYVhIOWy9STYSYjSpXCKTq9iXkRkdY+0TgzNQw9yAVEEo7yj3vVWvRP6yQ9O2t59+TviIVvldkKi/KNVclG6fcc+plNTXdwVuwK5mLcTLdBGTlEHK9gG0i7rzu6xWU0l1XKx46/+zxrVtXb1ORW1d7WVtXV1GE31kbf5nkfR/0/dcYGnLInw1ECXwf5NfGERmPbWHFWdkHZ7d4TTwBVEkmENjTm5FbV9uTZ0t3+UpxSI9nV1dXR1NcL5mhYWqgNEB1KSfVftoyzfeFrLc+UMN0Wjoa8nlXAVIi5wDUbh9gczDNZQO4rMZ/DGQCTUPxVJdhx0K4hGaUQcacL9RrDadOaxhuKz//ttpJ60eSOKqhqddbX1dTV");
        private static int[] order = new int[] { 2,3,7,8,10,5,8,8,10,10,10,11,12,13,14 };
        private static int key = 212;

        public static readonly bool IsPopulated = true;

        public static byte[] Data() {
        	if (IsPopulated == false)
        		return null;
            return Obfuscator.DeObfuscate(data, order, key);
        }
    }
}
#endif
