//
//  QuickSDKInterfaceUnity.h
//  Unity-iPhone
//
//  Created by zzw on 15-9-10.
//
//

#ifndef _QUICKSDKINTERFACE_UNITY_H_
#define _QUICKSDKINTERFACE_UNITY_H_


#if defined(__cplusplus)
extern "C"{
#endif
    extern void quicksdk_nativeSetListener(const char *gameObjectName);
    extern void quicksdk_nativeLogin();
    extern void quicksdk_nativeLogout();
    extern void quicksdk_nativePay(const char *goodsId, const char *goodsName, const char *goodsDesc, const char *quantifier, const char *cpOrderId, const char *callbackUrl, const char *extrasParams, double price, double amount, int count, const char *serverId, const char *serverName, const char *gameRoleName, const char *gameRoleId, const char *gameRoleBalance, const char *vipLevel, const char *gameRoleLevel, const char *partyName, const char *fightPower, const char * profession);
    extern const char* quicksdk_nativeUserId();
//    extern void quicksdk_nativeUpdateRoleInfoWith(const char *serverId, const char *serverName, const char *gameRoleName, const char *gameRoleId, const char *gameRoleBalance, const char *vipLevel, const char *gameRoleLevel, const char *partyName);
    //isCreate表示是否为刚刚创建角色
    extern void quicksdk_nativeUpdateRoleInfo(const char *serverId, const char *serverName, const char *gameRoleName, const char *gameRoleId, const char *gameRoleBalance, const char *vipLevel, const char *gameRoleLevel, const char *partyName, const char *creatTime, const char *fightPower, const char * profession, BOOL isCreate);
    extern void quicksdk_nativeEnterYunKeFuCenter(const char *gameRoleId, const char *gameRoleName, const char *serverName, const char *vipLevel);
    //获取商品信息
    extern void quicksdk_getLocalized(const char *productIds);
     // 是否开启第三方登录
    extern void quicksdk_openThirdLogin(BOOL thirdLogin);
     // 获取当前用户的ID
    extern const char *quicksdk_getIdCode();
    //是否游客账号
    extern bool quicksdk_isGuester();
    //绑定身份证
     extern void quicksdk_ShowCertification();
    //游客绑定并绑定身份证
    extern void quicksdk_BindCertification();
    
    extern int quicksdk_nativeEnterUserCenter();
    extern int quicksdk_nativeEnterCustomerCenter();
/** 实名认证 show非0查询实名信息并展示实名认证界面 0仅查询实名信息 */
    extern int quicksdk_nativeRealNameAuth(int show);
    extern int quicksdk_nativeEnterBBS();
    extern int quicksdk_nativeShowToolBar(int place);
    extern int quicksdk_nativeHideToolBar();
    extern int quicksdk_nativePausedGame();
    extern bool quicksdk_nativeIsFunctionTypeSupported(int type);
    extern const char *quicksdk_nativeChannelName();
    extern const char *quicksdk_nativeChannelVersion();
    extern int quicksdk_nativeChannelType();
    extern const char* quicksdk_nativeGetParentChannelType();
    extern const char* quicksdk_nativeSDKVersion();
    extern const char* quicksdk_nativeGetConfigValue(const char* key);
    /** 显示游戏自定义隐私弹窗 must:是否必须同意 YES:弹窗仅有同意按钮 NO:同时显示不同意和同意按钮 */
    extern void quicksdk_nativeShowGameCustomPrivacyView(BOOL must);
    extern void quicksdk_nativeExitGame();
    
#if defined(__cplusplus)
}
#endif

#endif
