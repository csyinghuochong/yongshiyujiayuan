package com.qk.game;

import android.app.Activity;
import android.os.Bundle;

import com.qk.unity.QuickUnityPlayerproxyActivity;
import com.quicksdk.Sdk;
import com.quicksdk.utility.AppConfig;

public class MainActivity extends QuickUnityPlayerproxyActivity {

	public Activity activity;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		activity = this;
	}

	@Override
	public String getProductCode() {
		return AppConfig.getInstance().getConfigValue("product_code");
	}

	@Override
	public String getProductKey() {
		return AppConfig.getInstance().getConfigValue("product_key");
	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		super.onBackPressed();
		Sdk.getInstance().exit(activity);
	}
}
